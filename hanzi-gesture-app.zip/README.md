# 手势交互汉字拆分与字帖

Flask 单页应用：前端静态资源 + `/api/split_char`（火山方舟）+ `/api/assets` 字帖底图。

## 环境变量

| 变量 | 说明 |
|------|------|
| `ARK_API_KEY` | **必填**，火山方舟 API Key |
| `HANZI_ASSET_DIR` | 可选，字帖背景 PNG 目录，默认项目下 `assets/` |

## 本地运行

```bash
python -m venv .venv
.venv\Scripts\activate   # Windows
# source .venv/bin/activate  # Linux/macOS
pip install -r requirements.txt
set ARK_API_KEY=你的密钥   # Windows cmd
# export ARK_API_KEY=...   # Linux/macOS
python app.py
```

浏览器访问 `http://127.0.0.1:5000`。

## Linux 服务器部署（Gunicorn）

```bash
cd /path/to/app
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pip install gunicorn
export ARK_API_KEY="你的密钥"
# 对外监听示例：
gunicorn -w 2 -b 0.0.0.0:8000 app:app
```

前面可接 Nginx 反代 `proxy_pass http://127.0.0.1:8000;`，静态文件也可由 Nginx 直接托管 `static/` 以减轻 Python 负载（可选）。

## 目录说明

- `app.py` — Flask 入口
- `templates/` — `index.html`
- `static/` — `gestures.js`、`style.css`
- `assets/` — 可选，放入字帖用 PNG，通过 `/api/assets` 列出

## 前端依赖（CDN）

页面使用 jsDelivr 加载 MediaPipe Hands、html-to-image。**服务器需能访问外网 CDN**，否则手势与导出截图需改成本地资源。

## 发布包

使用仓库内 `pack_release.ps1` 生成 `hanzi-gesture-app.zip`（不含 `__pycache__`、不含 `.venv`），上传服务器解压后按上文配置运行。
